package com.gathin.tvhome;
import java.util.Locale;

final class MirrorNames {
    private MirrorNames(){ }
    static boolean isMirroring(String label){
        String s=label==null?"":label.toLowerCase(Locale.ROOT);
        return s.contains("mirror")||s.contains("miracast")||s.contains("انعكاس")
            ||s.contains("عكس الشاشة")||s.contains("تكرار الشاشة")||s.contains("عرض لاسلكي");
    }
    static boolean isServiceOrFactory(String component){
        String s=component.toLowerCase(Locale.ROOT);
        return s.contains("factory")||s.contains("servicemode")||s.contains("hkcfac")||s.contains("agingtest");
    }
}
