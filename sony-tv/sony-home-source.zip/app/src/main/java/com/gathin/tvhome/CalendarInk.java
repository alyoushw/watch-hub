package com.gathin.tvhome;

/** Extract the printed glyphs without OCR: original characters, no paper or table rules. */
final class CalendarInk {
    private CalendarInk() { }

    static int[] transparentWhite(int[] pixels, int width, int height) {
        if (width <= 0 || height <= 0 || pixels.length != width * height)
            throw new IllegalArgumentException("Invalid calendar dimensions");
        int[] out = new int[pixels.length];
        boolean[] ink = new boolean[pixels.length];
        for (int i = 0; i < pixels.length; i++) {
            int p = pixels[i];
            int min = Math.min((p >>> 16) & 255, Math.min((p >>> 8) & 255, p & 255));
            // Paper is transparent. Colour and dark ink become the same quiet white.
            int alpha = Math.min(255, Math.max(0, (200 - min) * 255 / 145));
            if(alpha<65)alpha=0;
            out[i] = (alpha << 24) | 0x00FFFFFF;
            ink[i] = alpha >= 65;
        }
        // Break border intersections first, so a table corner cannot become one L-shaped component.
        for (int y=0;y<height;y++) {
            if(y>=3 && y<height-3)continue;
            int count=0;for(int x=0;x<width;x++)if(ink[y*width+x])count++;
            if(count>width*0.65)for(int x=0;x<width;x++){out[y*width+x]=0;ink[y*width+x]=false;}
        }
        for (int x=0;x<width;x++) {
            int count=0;for(int y=0;y<height;y++)if(ink[y*width+x])count++;
            if(count>height*0.85)for(int y=0;y<height;y++){out[y*width+x]=0;ink[y*width+x]=false;}
        }
        boolean[] seen = new boolean[pixels.length];
        int[] queue = new int[pixels.length];
        for (int start = 0; start < ink.length; start++) {
            if (!ink[start] || seen[start]) continue;
            int head = 0, tail = 1;
            queue[0] = start; seen[start] = true;
            int left = width, right = 0, top = height, bottom = 0;
            while (head < tail) {
                int at = queue[head++], x = at % width, y = at / width;
                left = Math.min(left, x); right = Math.max(right, x);
                top = Math.min(top, y); bottom = Math.max(bottom, y);
                for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                    if (dx == 0 && dy == 0) continue;
                    int nx = x + dx, ny = y + dy;
                    if (nx < 0 || nx >= width || ny < 0 || ny >= height) continue;
                    int n = ny * width + nx;
                    if (ink[n] && !seen[n]) { seen[n] = true; queue[tail++] = n; }
                }
            }
            int w = right - left + 1, h = bottom - top + 1;
            boolean horizontalRule = w >= 28 && w > h * 12 && h <= Math.max(8, height / 3);
            boolean verticalRule = h >= height * 0.85 && w <= 2
                    && (top == 0 || bottom == height - 1);
            if (horizontalRule || verticalRule) {
                // Include the rule's antialiasing, but never erase neighbouring glyph components.
                for (int k = 0; k < tail; k++) {
                    int at = queue[k]; out[at] = 0;
                    int x = at % width, y = at / width;
                    for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                        int nx=x+dx, ny=y+dy;
                        if(nx>=0 && nx<width && ny>=0 && ny<height && !ink[ny*width+nx]) out[ny*width+nx]=0;
                    }
                }
            }
        }
        return out;
    }
}
