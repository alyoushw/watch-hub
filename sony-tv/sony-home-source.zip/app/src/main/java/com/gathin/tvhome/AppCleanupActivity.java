package com.gathin.tvhome;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;
import java.util.*;

/** Opens Android's app details; never deletes data or disables packages on its own. */
public final class AppCleanupActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(32,24,32,24);
        TextView title=new TextView(this);title.setText("إدارة التطبيقات والتخزين المؤقت");title.setTextSize(22);page.addView(title);
        android.app.ActivityManager.MemoryInfo memory=new android.app.ActivityManager.MemoryInfo();
        ((android.app.ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(memory);
        android.os.StatFs disk=new android.os.StatFs(android.os.Environment.getDataDirectory().getAbsolutePath());
        TextView stats=new TextView(this);
        stats.setText("RAM المتاحة الآن: "+android.text.format.Formatter.formatFileSize(this,memory.availMem)
            +" من "+android.text.format.Formatter.formatFileSize(this,memory.totalMem)
            +"\nالتخزين المتاح: "+android.text.format.Formatter.formatFileSize(this,disk.getAvailableBytes())
            +" من "+android.text.format.Formatter.formatFileSize(this,disk.getTotalBytes())
            +"\nهذه قراءة لحظة فتح الصفحة؛ انخفاض RAM المتاحة وحده لا يثبت وجود مشكلة.");
        page.addView(stats);
        TextView help=new TextView(this);help.setText("اختر تطبيقًا لفتح إعداداته، ثم التخزين ← مسح ذاكرة التخزين المؤقت. مسح البيانات يحذف إعدادات التطبيق وتسجيل الدخول. إخفاء الأيقونة وحده لا يزيل التطبيق.");page.addView(help);
        ListView list=new ListView(this);page.addView(list,new LinearLayout.LayoutParams(-1,0,1));setContentView(page);
        java.util.List<ApplicationInfo> apps=new ArrayList<>(getPackageManager().getInstalledApplications(0));
        apps.removeIf(info -> getPackageName().equals(info.packageName));
        apps.sort(Comparator.comparingInt((ApplicationInfo info)->(info.flags&ApplicationInfo.FLAG_SYSTEM)==0?0:1)
            .thenComparing(info->info.loadLabel(getPackageManager()).toString()));
        java.util.List<String> labels=new ArrayList<>();
        for(ApplicationInfo info:apps)labels.add(info.loadLabel(getPackageManager())+"\n"+
            ((info.flags&ApplicationInfo.FLAG_SYSTEM)==0?"تطبيق مثبت":"تطبيق مدمج — راجع وظيفته قبل التعطيل")+" · "+info.packageName);
        list.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,labels));
        list.setOnItemClickListener((parent,view,position,id)->{
            try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+apps.get(position).packageName)));}
            catch(RuntimeException e){Toast.makeText(this,"تعذر فتح إعدادات التطبيق",Toast.LENGTH_SHORT).show();}
        });
    }
}
