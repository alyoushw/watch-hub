package com.gathin.tvhome;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.tv.TvContract;
import android.media.tv.TvInputInfo;
import android.media.tv.TvInputManager;
import android.net.Uri;
import android.os.Build;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

/** Opens installed receiver capabilities; does not implement or enable a casting protocol. */
final class MirrorMenu {
    private static final String APPLE="apple", ANDROID="android";
    private static final String AIRPLAY="io.github.jqssun.airplay";
    private static final String SONY_PACKAGE="com.sony.dtv.networkapp.wifidirect";
    private static final String SONY_ACTIVITY=SONY_PACKAGE+".ui.screens.ScreenMirroringHomeActivity";
    private static final String[] TCL_PACKAGES={"com.tcl.miracast","com.tcl.MultiScreenInteraction_TV","com.tcl.magiconnectfree"};

    static void show(Activity a){
        new AlertDialog.Builder(a).setTitle("انعكاس الشاشة")
            .setItems(new String[]{"أجهزة Apple — AirPlay","أجهزة Android — انعكاس الشاشة","اختيار تطبيق الانعكاس"},(d,which)->{
                if(which==0)openApple(a);
                else if(which==1)openAndroid(a);
                else new AlertDialog.Builder(a).setTitle("تطبيق الاستقبال")
                    .setItems(new String[]{"لأجهزة Apple","لأجهزة Android"},(dialog,index)->chooseApp(a,index==0?APPLE:ANDROID))
                    .setNegativeButton("إغلاق",null).show();
            }).setNegativeButton("إغلاق",null).show();
    }
    private static SharedPreferences prefs(Activity a){return a.getSharedPreferences("mirror_receivers",0);}
    private static boolean openSaved(Activity a,String platform){
        ComponentName target=ComponentName.unflattenFromString(prefs(a).getString(platform,""));
        if(target==null)return false;
        if(openComponent(a,target))return true;
        prefs(a).edit().remove(platform).apply();
        Toast.makeText(a,"التطبيق المختار غير متاح؛ جارٍ البحث عن مستقبِل آخر",Toast.LENGTH_SHORT).show();
        return false;
    }
    private static void openApple(Activity a){
        if(openSaved(a,APPLE)||openPackage(a,AIRPLAY))return;
        new AlertDialog.Builder(a).setMessage("اختَر تطبيق استقبال AirPlay مثبّتًا، أو ثبّت AirPlay Server ثم افتحه من هذا الزر. يجب أن تكون أجهزة Apple والتلفزيون على الشبكة المحلية نفسها.")
            .setPositiveButton("اختيار تطبيق",(d,w)->chooseApp(a,APPLE))
            .setNeutralButton("تحميل AirPlay Server",(d,w)->{
                try{a.startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://f-droid.org/packages/io.github.jqssun.airplay/")));}
                catch(RuntimeException e){Toast.makeText(a,"افتح صفحة AirPlay Server في F-Droid",Toast.LENGTH_LONG).show();}
            }).setNegativeButton("إغلاق",null).show();
    }
    private static void openAndroid(Activity a){
        if(openSaved(a,ANDROID))return;
        // Sony's INPUT row may open a normal activity rather than a TvInputManager passthrough.
        // Resolve it explicitly, and never try a disabled/unexported/protected activity.
        boolean tcl=Build.MANUFACTURER.toLowerCase(Locale.ROOT).contains("tcl");
        if(tcl&&openTcl(a))return;
        if(openComponent(a,new ComponentName(SONY_PACKAGE,SONY_ACTIVITY)))return;
        if(openPackage(a,SONY_PACKAGE)||openPackage(a,"screnmirroring.com"))return;
        if(!tcl&&openTcl(a))return;
        // The owner's activity log confirms Sony INPUT uses this screen. If the firmware
        // protects the receiver itself, open the normal input selector when it is exported.
        if(Build.MANUFACTURER.toLowerCase(Locale.ROOT).contains("sony")
                &&openComponent(a,new ComponentName("com.sony.dtv.tvx","com.sony.dtv.tvx.inputselect.InputSelectionActivity")))return;
        TvInputManager manager=(TvInputManager)a.getSystemService(Activity.TV_INPUT_SERVICE);
        if(manager!=null)for(TvInputInfo input:manager.getTvInputList()){
            String label=String.valueOf(input.loadLabel(a)).toLowerCase(Locale.ROOT);
            if(input.isPassthroughInput()&&MirrorNames.isMirroring(label)){
                try{a.startActivity(new Intent(Intent.ACTION_VIEW,TvContract.buildChannelUriForPassthroughInput(input.getId())));return;}
                catch(RuntimeException ignored){ }
            }
        }
        new AlertDialog.Builder(a).setMessage("لم يوفّر النظام اختصار استقبال يمكن للانشر فتحه تلقائيًا. اختَر تطبيق استقبال مثبّتًا، أو افتح Screen mirroring من قائمة المدخلات الأصلية. طرق الانعكاس المتاحة تختلف حسب موديل الشاشة والهاتف.")
            .setPositiveButton("اختيار تطبيق",(d,w)->chooseApp(a,ANDROID))
            .setNegativeButton("إغلاق",null).show();
    }
    private static boolean openTcl(Activity a){for(String pkg:TCL_PACKAGES)if(openPackage(a,pkg))return true;return false;}
    private static boolean openPackage(Activity a,String pkg){
        PackageManager pm=a.getPackageManager();
        Intent i=pm.getLeanbackLaunchIntentForPackage(pkg);
        if(i==null)i=pm.getLaunchIntentForPackage(pkg);
        return i!=null&&i.getComponent()!=null&&openComponent(a,i.getComponent());
    }
    private static boolean canOpen(Activity a,ComponentName target){
        try{
            ActivityInfo info=a.getPackageManager().getActivityInfo(target,0);
            return info.exported&&info.enabled&&info.applicationInfo.enabled
                &&(info.permission==null||a.checkSelfPermission(info.permission)==PackageManager.PERMISSION_GRANTED);
        }catch(PackageManager.NameNotFoundException e){return false;}
    }
    private static boolean openComponent(Activity a,ComponentName target){
        if(!canOpen(a,target))return false;
        try{a.startActivity(new Intent(Intent.ACTION_MAIN).setComponent(target));return true;}
        catch(RuntimeException e){return false;}
    }
    private static void chooseApp(Activity a,String platform){
        PackageManager pm=a.getPackageManager();
        LinkedHashMap<String,ComponentName> components=new LinkedHashMap<>();
        ComponentName sony=new ComponentName(SONY_PACKAGE,SONY_ACTIVITY);
        if(canOpen(a,sony))components.put(sony.flattenToString(),sony);
        for(String category:new String[]{Intent.CATEGORY_LEANBACK_LAUNCHER,Intent.CATEGORY_LAUNCHER}){
            for(ResolveInfo row:pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(category),0)){
                ActivityInfo info=row.activityInfo;if(info==null||a.getPackageName().equals(info.packageName))continue;
                ComponentName target=new ComponentName(info.packageName,info.name);
                if(MirrorNames.isServiceOrFactory(target.flattenToString())||!canOpen(a,target))continue;
                components.put(target.flattenToString(),target);
            }
        }
        List<ComponentName> targets=new ArrayList<>(components.values());
        targets.sort((x,y)->label(a,x).compareToIgnoreCase(label(a,y)));
        String[] labels=new String[targets.size()+1];labels[0]="الاكتشاف التلقائي";
        for(int i=0;i<targets.size();i++)labels[i+1]=label(a,targets.get(i));
        new AlertDialog.Builder(a).setTitle("اختَر تطبيق استقبال الانعكاس المثبّت")
            .setItems(labels,(dialog,index)->{
                if(index==0){prefs(a).edit().remove(platform).apply();Toast.makeText(a,"تم تفعيل الاكتشاف التلقائي",Toast.LENGTH_SHORT).show();return;}
                ComponentName target=targets.get(index-1);
                prefs(a).edit().putString(platform,target.flattenToString()).apply();
                if(!openComponent(a,target))Toast.makeText(a,"تعذّر فتح التطبيق المختار",Toast.LENGTH_LONG).show();
            }).setNegativeButton("إغلاق",null).show();
    }
    private static String label(Activity a,ComponentName target){
        try{return a.getPackageManager().getActivityInfo(target,0).loadLabel(a.getPackageManager()).toString();}
        catch(PackageManager.NameNotFoundException e){return target.getPackageName();}
    }
}
