package com.gathin.tvhome;

import android.app.*;
import android.content.*;
import android.media.tv.*;
import android.net.Uri;
import java.util.Locale;

final class MirrorMenu {
    static void show(Activity a){new AlertDialog.Builder(a).setTitle("Screen Mirror — انعكاس الشاشة")
        .setItems(new String[]{"أجهزة Apple — AirPlay", "أجهزة Android — انعكاس Sony"},(d,which)->{
            if(which==0){
                Intent i=a.getPackageManager().getLeanbackLaunchIntentForPackage("io.github.jqssun.airplay");
                if(i==null)i=a.getPackageManager().getLaunchIntentForPackage("io.github.jqssun.airplay");
                if(i!=null){a.startActivity(i);return;}
                new AlertDialog.Builder(a).setMessage("ثبّت AirPlay Server أولاً من F-Droid. ثم افتحه من هذا الزر واجعل الآيفون والتلفزيون على نفس الشبكة، واختر التلفزيون من انعكاس الشاشة في الآيفون.")
                    .setPositiveButton("صفحة التحميل",(x,y)->{try{a.startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://f-droid.org/packages/io.github.jqssun.airplay/")));}catch(RuntimeException ignored){}})
                    .setNegativeButton("إغلاق",null).show();return;
            }
            TvInputManager manager=(TvInputManager)a.getSystemService(Context.TV_INPUT_SERVICE);
            if(manager!=null)for(TvInputInfo input:manager.getTvInputList()){
                String label=String.valueOf(input.loadLabel(a)).toLowerCase(Locale.ROOT);
                if(input.isPassthroughInput()&&(label.contains("mirror")||label.contains("انعكاس")||label.contains("عكس"))){
                    try{a.startActivity(new Intent(Intent.ACTION_VIEW,TvContract.buildChannelUriForPassthroughInput(input.getId())));return;}catch(RuntimeException ignored){}
                }
            }
            new AlertDialog.Builder(a).setMessage("لم يظهر مدخل انعكاس Sony للتطبيق. افتح INPUT من ريموت سوني ثم Screen mirroring، واختر الشاشة من Smart View أو انعكاس الشاشة في هاتف Android. يجب إبقاء خدمات Miracast الأصلية مفعّلة.")
                .setPositiveButton("حسنًا",null).show();
        }).setNegativeButton("إغلاق",null).show();}
}
