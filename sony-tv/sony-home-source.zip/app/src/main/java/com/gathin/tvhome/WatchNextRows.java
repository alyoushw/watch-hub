package com.gathin.tvhome;

/** Provider-independent row validation and compact labels. No Android or network access. */
final class WatchNextRows {
    private WatchNextRows() { }
    static boolean usable(String owner,String uri) {
        return owner!=null && owner.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+")
            && uri!=null && !uri.trim().isEmpty();
    }
    static String label(String app,String title,String season,String episode) {
        String value=app+" · "+(title==null||title.trim().isEmpty()?"متابعة المشاهدة":title);
        if(episode!=null&&!episode.trim().isEmpty()) {
            if(season!=null&&!season.trim().isEmpty())value+=" · "+season+"/"+episode;
            else value+=" · "+episode;
        }
        return value;
    }
}
