package com.gathin.tvhome;

import android.app.Activity;
import android.app.AlertDialog;
import android.appwidget.*;
import android.content.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.util.*;

/** Android's own widget host: providers must offer a widget and allow binding on this TV. */
public final class WidgetBoardActivity extends Activity {
    static final int HOST=1448;
    private static final int BIND=1,CONFIGURE=2;
    private AppWidgetHost host;
    private LinearLayout board;
    private int pending=-1;
    static SharedPreferences prefs(Context c){return c.getSharedPreferences("sony_widgets",0);}
    static int selected(Context c){return prefs(c).getInt("selected",-1);}
    @Override public void onCreate(Bundle state){
        super.onCreate(state);host=new AppWidgetHost(this,HOST);
        if(state!=null)pending=state.getInt("pending",-1);
        ScrollView scroll=new ScrollView(this);board=new LinearLayout(this);board.setOrientation(LinearLayout.VERTICAL);board.setPadding(35,20,35,20);
        scroll.addView(board);setContentView(scroll);render();
    }
    private void render(){
        board.removeAllViews();
        Button add=new Button(this);add.setText("إضافة ويدجت إلى الشاشة الرئيسية");board.addView(add);add.setOnClickListener(v->choose());
        TextView note=new TextView(this);note.setText("اختر ويدجت لعرضه بجانب المواقيت. اضغط مطولاً على الويدجت لحذفه. التطبيقات التي لا توفر ويدجت لن تظهر هنا.");board.addView(note);
        for(int id:host.getAppWidgetIds()){
            AppWidgetProviderInfo info=AppWidgetManager.getInstance(this).getAppWidgetInfo(id);
            if(info==null)continue;
            Button select=new Button(this);select.setText(info.loadLabel(getPackageManager())+(selected(this)==id?" ✓":" — عرض في الرئيسية"));board.addView(select);
            select.setOnClickListener(v->{prefs(this).edit().putInt("selected",id).apply();render();});
            AppWidgetHostView widget=host.createView(this,id,info);
            widget.updateAppWidgetSize(null,500,120,500,120);
            board.addView(widget,new LinearLayout.LayoutParams(-1,Math.round(160*getResources().getDisplayMetrics().density)));
            select.setOnLongClickListener(v->{new AlertDialog.Builder(this).setMessage("حذف هذا الويدجت؟").setPositiveButton("حذف",(d,w)->{
                host.deleteAppWidgetId(id);if(selected(this)==id)prefs(this).edit().remove("selected").apply();render();
            }).setNegativeButton("إلغاء",null).show();return true;});
        }
    }
    private void choose(){
        List<AppWidgetProviderInfo> providers=new ArrayList<>(AppWidgetManager.getInstance(this).getInstalledProviders());
        providers.sort(Comparator.comparing(p->p.loadLabel(getPackageManager())));
        String[] labels=new String[providers.size()];for(int i=0;i<labels.length;i++)labels[i]=providers.get(i).loadLabel(getPackageManager());
        new AlertDialog.Builder(this).setTitle("ويدجت التطبيقات المثبتة").setItems(labels,(dialog,index)->{
            cancelPending();pending=host.allocateAppWidgetId();AppWidgetProviderInfo info=providers.get(index);
            if(AppWidgetManager.getInstance(this).bindAppWidgetIdIfAllowed(pending,info.provider)){configure();return;}
            try {startActivityForResult(new Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,pending).putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER,info.provider),BIND);}
            catch(RuntimeException e){cancelPending();Toast.makeText(this,"نظام التلفزيون لا يسمح بربط هذا الويدجت",Toast.LENGTH_LONG).show();}
        }).setNegativeButton("إلغاء",null).show();
    }
    private void configure(){
        AppWidgetProviderInfo info=AppWidgetManager.getInstance(this).getAppWidgetInfo(pending);
        if(info==null){cancelPending();return;}
        if(info.configure!=null){
            try{host.startAppWidgetConfigureActivityForResult(this,pending,0,CONFIGURE,null);}
            catch(RuntimeException e){cancelPending();Toast.makeText(this,"تعذر إعداد الويدجت",Toast.LENGTH_LONG).show();}
        }else finishPending();
    }
    private void finishPending(){prefs(this).edit().putInt("selected",pending).apply();pending=-1;render();}
    private void cancelPending(){if(pending!=-1)host.deleteAppWidgetId(pending);pending=-1;}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
        if(request!=BIND&&request!=CONFIGURE)return;
        if(result!=RESULT_OK){cancelPending();return;}
        if(request==BIND)configure();else finishPending();
    }
    @Override protected void onSaveInstanceState(Bundle out){out.putInt("pending",pending);super.onSaveInstanceState(out);}
    @Override protected void onStart(){super.onStart();host.startListening();}
    @Override protected void onStop(){host.stopListening();super.onStop();}
    @Override protected void onDestroy(){if(isFinishing())cancelPending();super.onDestroy();}
}
