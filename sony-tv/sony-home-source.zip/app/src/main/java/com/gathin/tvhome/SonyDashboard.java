package com.gathin.tvhome;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.media.tv.TvContract;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Personal, offline Home panel. It reads original calendar pixels and searchable TV rows. */
final class SonyDashboard extends LinearLayout {
    private final Activity activity;
    private final ImageView times, occasion;
    private final TextView date;
    private final LinearLayout next;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService reader = Executors.newSingleThreadExecutor();
    private boolean active;
    private int generation;
    private String calendarDate;
    private android.appwidget.AppWidgetHost widgetHost;
    private android.widget.FrameLayout widgetSlot;
    private int widgetId=-1;
    private final ContentObserver observer = new ContentObserver(handler) {
        @Override public void onChange(boolean selfChange) { loadNext(); }
    };
    private final Runnable tick = new Runnable() {
        @Override public void run() { if (active) { calendar(); handler.postDelayed(this, 60000); } }
    };

    SonyDashboard(Activity a) {
        super(a); activity=a; setOrientation(VERTICAL); setPadding(dp(12),dp(5),dp(12),dp(5));
        setBackgroundColor(0xC9111822);
        date = text(12);
        LinearLayout heading=new LinearLayout(a);
        heading.addView(date,new LinearLayout.LayoutParams(0,-2,1));
        heading.addView(chip("الويدجت والتنظيف",()->new android.app.AlertDialog.Builder(activity)
            .setItems(new String[]{"ويدجت التطبيقات", "إدارة التطبيقات والكاش"},(dialog,index)->
                activity.startActivity(new Intent(activity,index==0?WidgetBoardActivity.class:AppCleanupActivity.class)))
            .setNegativeButton("إغلاق",null).show()));
        addView(heading);
        LinearLayout labels=new LinearLayout(a);
        for (String label : new String[]{"المغرب", "الظهر", "الشروق", "الصبح", "الإمساك"}) {
            TextView t=text(12); t.setText(label); t.setGravity(Gravity.CENTER);
            labels.addView(t,new LinearLayout.LayoutParams(dp(100),dp(18)));
        }
        addView(labels);
        times=new ImageView(a); times.setScaleType(ImageView.ScaleType.FIT_XY);
        times.setContentDescription("أوقات الصلاة الأصلية من تقويم الزهراء بالترتيب: المغرب، الظهر، الشروق، الصبح، الإمساك");
        FrameLayout timeRow=new FrameLayout(a);
        timeRow.addView(times,new FrameLayout.LayoutParams(dp(500),dp(30),Gravity.LEFT|Gravity.CENTER_VERTICAL));
        widgetSlot=new FrameLayout(a);
        timeRow.addView(widgetSlot,new FrameLayout.LayoutParams(dp(200),dp(55),Gravity.RIGHT|Gravity.CENTER_VERTICAL));
        addView(timeRow,new LinearLayout.LayoutParams(dp(720),dp(55)));
        occasion=new ImageView(a); occasion.setScaleType(ImageView.ScaleType.FIT_CENTER);
        occasion.setContentDescription("المناسبة كما طُبعت في تقويم الزهراء");
        addView(occasion,new LinearLayout.LayoutParams(dp(720),dp(28)));

        widgetHost=new android.appwidget.AppWidgetHost(a,WidgetBoardActivity.HOST);
        next=new LinearLayout(a); next.setGravity(Gravity.CENTER_VERTICAL);
        addView(next,new LinearLayout.LayoutParams(-1,dp(34)));
        setVisibility(VISIBLE);
    }
    private int dp(int n) { return Math.round(n*getResources().getDisplayMetrics().density); }
    private TextView text(int size) { TextView t=new TextView(activity);t.setTextSize(size);t.setTextColor(-1);return t; }
    private TextView chip(String label,Runnable action) {
        TextView t=text(12);t.setText(label);t.setPadding(dp(9),dp(4),dp(9),dp(4));t.setFocusable(true);
        t.setBackgroundResource(R.drawable.pill_bg);t.setTextColor(getResources().getColorStateList(R.color.sony_pill_text, null));t.setOnClickListener(v->action.run());
        return t;
    }
    void start() {
        active=true;calendar();
        int selected=WidgetBoardActivity.selected(activity);
        if(selected!=widgetId){
            widgetId=selected;widgetSlot.removeAllViews();
            android.appwidget.AppWidgetProviderInfo info=android.appwidget.AppWidgetManager.getInstance(activity).getAppWidgetInfo(selected);
            if(info!=null){
                android.appwidget.AppWidgetHostView view=widgetHost.createView(activity,selected,info);
                view.updateAppWidgetSize(null,200,60,200,60);widgetSlot.addView(view);
                widgetSlot.setVisibility(VISIBLE);
            }else widgetSlot.setVisibility(GONE);
        }
        widgetHost.startListening();handler.removeCallbacks(tick);handler.postDelayed(tick,60000);
        try { activity.getContentResolver().registerContentObserver(TvContract.WatchNextPrograms.CONTENT_URI,true,observer); }
        catch (RuntimeException ignored) { }
        loadNext();
    }
    void stop() {
        active=false;generation++;widgetHost.stopListening();handler.removeCallbacks(tick);
        activity.getContentResolver().unregisterContentObserver(observer);
    }
    void close() { stop();reader.shutdownNow(); }
    private void calendar() {
        String today=LocalDate.now(ZoneId.of("Asia/Riyadh")).toString();
        if (today.equals(calendarDate)) return;
        calendarDate=today;
        date.setText("تقويم الزهراء · الأحساء · "+today);
        try (InputStream t=getContext().getAssets().open("zahra/"+today+"-times.webp");
             InputStream o=getContext().getAssets().open("zahra/"+today+"-occasion.webp")) {
            times.setImageBitmap(BitmapFactory.decodeStream(t));occasion.setImageBitmap(BitmapFactory.decodeStream(o));
            times.setVisibility(VISIBLE);occasion.setVisibility(VISIBLE);
        } catch (java.io.IOException e) {
            times.setImageDrawable(null);occasion.setImageDrawable(null);
            times.setVisibility(GONE);occasion.setVisibility(GONE);
            date.setText("تقويم الزهراء · لا توجد مواقيت لهذا التاريخ في ملف 1448 هـ");
        }
    }
    void refreshNext() { loadNext(); }
    private void loadNext() {
        if (!active) return;
        int token=++generation;
        if (activity.checkSelfPermission("android.permission.READ_TV_LISTINGS")!=PackageManager.PERMISSION_GRANTED) {
            next.removeAllViews();
            next.addView(chip("السماح بعرض متابعة المشاهدة",()->activity.requestPermissions(new String[]{"android.permission.READ_TV_LISTINGS"},74)));
            return;
        }
        reader.execute(()-> {
            java.util.List<String[]> rows=new java.util.ArrayList<>();
            try (Cursor c=activity.getContentResolver().query(TvContract.WatchNextPrograms.CONTENT_URI,
                    new String[]{"title","intent_uri","season_display_number","episode_display_number","package_name"},null,null,null)) {
                if(c!=null) while(c.moveToNext()) {
                    // User asked for Watch Hub, not unrelated recommendations from all providers.
                    if (!"com.alyoushw.watchhub".equals(c.getString(4))) continue;
                    String uri=c.getString(1);if(uri==null)continue;
                    String label=c.getString(0);
                    if(c.getString(3)!=null)label+=" · "+c.getString(2)+"/"+c.getString(3);
                    rows.add(new String[]{label,uri});if(rows.size()==4)break;
                }
            }catch(RuntimeException ignored) { }
            handler.post(()-> {
                if(!active||token!=generation)return;
                next.removeAllViews();
                for(String[] row:rows)next.addView(chip(row[0],()-> {
                    try { activity.startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(row[1])).setPackage("com.alyoushw.watchhub")); }
                    catch(RuntimeException e){Toast.makeText(activity,"تعذر فتح Watch Hub",Toast.LENGTH_SHORT).show();}
                }));
                if(rows.isEmpty()) { TextView t=text(12);t.setText("فعّل Watch Next من إعدادات Watch Hub لعرض الأعمال التي تتابعها");next.addView(t); }
            });
        });
    }
}
