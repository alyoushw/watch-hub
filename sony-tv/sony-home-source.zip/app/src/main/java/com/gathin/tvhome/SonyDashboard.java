package com.gathin.tvhome;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.media.tv.TvContract;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Personal, offline Home panel. It reads original calendar pixels and searchable TV rows. */
final class SonyDashboard extends LinearLayout {
    private final Activity activity;
    private final ImageView times, occasion;
    private final TextView date;
    private final LinearLayout next;
    private final HorizontalScrollView nextScroll;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService reader = Executors.newSingleThreadExecutor();
    private boolean active;
    private int generation;
    private String calendarDate;
    private android.appwidget.AppWidgetHost widgetHost;
    private android.widget.FrameLayout widgetSlot;
    private int widgetId=-1;
    private final ContentObserver observer = new ContentObserver(handler) {
        @Override public void onChange(boolean selfChange) { loadNext(); }
    };
    private final Runnable tick = new Runnable() {
        @Override public void run() { if (active) { calendar(); handler.postDelayed(this, 60000); } }
    };

    SonyDashboard(Activity a) {
        super(a); activity=a; setOrientation(VERTICAL);
        setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        // Small, unboxed information directly on the wallpaper, aligned with the clock.
        date=text(10); date.setTextColor(0x99FFFFFF); addView(date);
        LinearLayout labels=new LinearLayout(a);
        labels.setPadding(0,dp(5),0,0);
        for(String label:new String[]{"المغرب","الظهر","الشروق","الفجر","الإمساك"}){
            TextView t=text(10);t.setText(label);t.setTextColor(0xAAFFFFFF);t.setGravity(Gravity.CENTER);
            labels.addView(t,new LinearLayout.LayoutParams(0,dp(19),1));
        }
        addView(labels,new LinearLayout.LayoutParams(dp(330),-2));
        times=new ImageView(a);times.setScaleType(ImageView.ScaleType.FIT_XY);
        times.setAlpha(0.95f);
        times.setContentDescription("أوقات تقويم الزهراء الأصلية: المغرب، الظهر، الشروق، الفجر، الإمساك");
        addView(times,new LinearLayout.LayoutParams(dp(330),dp(23)));
        occasion=new ImageView(a);occasion.setScaleType(ImageView.ScaleType.FIT_CENTER);
        occasion.setAlpha(0.85f);occasion.setContentDescription("مناسبة اليوم من تقويم الزهراء");
        LinearLayout.LayoutParams occasionPosition=new LinearLayout.LayoutParams(dp(370),dp(32));
        occasionPosition.topMargin=dp(7);addView(occasion,occasionPosition);
        widgetSlot=new FrameLayout(a);widgetSlot.setVisibility(GONE);
        addView(widgetSlot,new LinearLayout.LayoutParams(dp(220),dp(60)));
        widgetHost=new android.appwidget.AppWidgetHost(a,WidgetBoardActivity.HOST);
        next=new LinearLayout(a);next.setGravity(Gravity.CENTER_VERTICAL);
        nextScroll=new HorizontalScrollView(a);nextScroll.setFillViewport(false);
        nextScroll.setHorizontalScrollBarEnabled(false);nextScroll.setVisibility(GONE);
        nextScroll.setContentDescription("متابعة المشاهدة من التطبيقات");
        nextScroll.addView(next,new FrameLayout.LayoutParams(-2,-1));
        addView(nextScroll,new LinearLayout.LayoutParams(-1,dp(40)));
        setVisibility(VISIBLE);
    }
    private int dp(int n) { return Math.round(n*getResources().getDisplayMetrics().density); }
    private TextView text(int size) { TextView t=new TextView(activity);t.setTextSize(size);t.setTextColor(-1);return t; }
    private TextView chip(String label,Runnable action) {
        TextView t=text(12);t.setText(label);t.setPadding(dp(9),dp(4),dp(9),dp(4));t.setFocusable(true);
        t.setBackgroundResource(R.drawable.pill_bg);t.setTextColor(getResources().getColorStateList(R.color.sony_pill_text, null));t.setOnClickListener(v->action.run());
        return t;
    }
    void start() {
        active=true;calendar();
        int selected=WidgetBoardActivity.selected(activity);
        if(selected!=widgetId){
            widgetId=selected;widgetSlot.removeAllViews();
            android.appwidget.AppWidgetProviderInfo info=android.appwidget.AppWidgetManager.getInstance(activity).getAppWidgetInfo(selected);
            if(info!=null){
                android.appwidget.AppWidgetHostView view=widgetHost.createView(activity,selected,info);
                view.updateAppWidgetSize(null,200,60,200,60);widgetSlot.addView(view);
                widgetSlot.setVisibility(VISIBLE);
            }else widgetSlot.setVisibility(GONE);
        }
        widgetHost.startListening();handler.removeCallbacks(tick);handler.postDelayed(tick,60000);
        try { activity.getContentResolver().registerContentObserver(TvContract.WatchNextPrograms.CONTENT_URI,true,observer); }
        catch (RuntimeException ignored) { }
        loadNext();
    }
    void stop() {
        active=false;generation++;widgetHost.stopListening();handler.removeCallbacks(tick);
        activity.getContentResolver().unregisterContentObserver(observer);
    }
    void close() { stop();reader.shutdownNow(); }
    private void calendar() {
        String today=LocalDate.now(ZoneId.of("Asia/Riyadh")).toString();
        if (today.equals(calendarDate)) return;
        calendarDate=today;
        date.setText("تقويم الزهراء · الأحساء");
        try (InputStream t=getContext().getAssets().open("zahra/"+today+"-times.webp");
             InputStream o=getContext().getAssets().open("zahra/"+today+"-occasion.webp")) {
            times.setImageBitmap(asInk(BitmapFactory.decodeStream(t)));
            occasion.setImageBitmap(asInk(BitmapFactory.decodeStream(o)));
            times.setVisibility(VISIBLE);occasion.setVisibility(VISIBLE);
        } catch (java.io.IOException e) {
            times.setImageDrawable(null);occasion.setImageDrawable(null);
            times.setVisibility(GONE);occasion.setVisibility(GONE);
            date.setText("تقويم الزهراء · لا توجد مواقيت لهذا التاريخ في ملف 1448 هـ");
        }
    }
    private Bitmap asInk(Bitmap original) {
        if(original==null)return null;
        int width=original.getWidth(),height=original.getHeight();
        int[] pixels=new int[width*height];original.getPixels(pixels,0,width,0,0,width,height);
        int[] ink=CalendarInk.transparentWhite(pixels,width,height);
        original.recycle();
        return Bitmap.createBitmap(ink,width,height,Bitmap.Config.ARGB_8888);
    }
    static void showTools(Activity activity) {
        new android.app.AlertDialog.Builder(activity)
            .setItems(new String[]{"ويدجت التطبيقات","إدارة التطبيقات والكاش","متابعة المشاهدة — Watch Next"},(dialog,index)-> {
                if(index==2){showNext(activity);return;}
                activity.startActivity(new Intent(activity,index==0?WidgetBoardActivity.class:AppCleanupActivity.class));
            })
            .setNegativeButton("إغلاق",null).show();
    }
    private static final String READ_LISTINGS="android.permission.READ_TV_LISTINGS";
    private static final class NextRow {
        final String label, uri, owner;
        NextRow(String label,String uri,String owner){this.label=label;this.uri=uri;this.owner=owner;}
    }
    private static final class NextResult {
        final java.util.List<NextRow> rows=new java.util.ArrayList<>();
        String error;
    }
    private static NextResult readNext(Activity activity) {
        NextResult result=new NextResult();
        try(Cursor c=activity.getContentResolver().query(TvContract.WatchNextPrograms.CONTENT_URI,
                new String[]{"title","intent_uri","season_display_number","episode_display_number","package_name","browsable"},
                null,null,"last_engagement_time_utc_millis DESC")) {
            if(c==null){result.error="لم يُرجع نظام التلفزيون بيانات متابعة المشاهدة.";return result;}
            PackageManager pm=activity.getPackageManager();
            java.util.Map<String,String> names=new java.util.HashMap<>();
            while(c.moveToNext() && result.rows.size()<20) {
                String owner=c.getString(4),uri=c.getString(1);
                // Keep the user's hidden cards hidden, and accept rows from every provider.
                if(c.getInt(5)==0 || !WatchNextRows.usable(owner,uri))continue;
                String name=names.get(owner);
                if(name==null){
                    try {name=pm.getApplicationLabel(pm.getApplicationInfo(owner,0)).toString();}
                    catch(PackageManager.NameNotFoundException e){name=owner;}
                    names.put(owner,name);
                }
                result.rows.add(new NextRow(WatchNextRows.label(name,c.getString(0),c.getString(2),c.getString(3)),uri,owner));
            }
        }catch(SecurityException e){result.error="نظام التلفزيون لم يسمح بقراءة بطاقات المتابعة. راجع إذن عرض قوائم التلفزيون للانشر.";}
        catch(RuntimeException e){result.error="تعذرت قراءة Watch Next من نظام التلفزيون. يمكن فحص الخدمة من اللابتوب.";}
        return result;
    }
    private static void openNext(Activity activity,NextRow row) {
        try {
            Intent intent=Intent.parseUri(row.uri,Intent.URI_INTENT_SCHEME);
            intent.setSelector(null);
            if(intent.getComponent()!=null && !row.owner.equals(intent.getComponent().getPackageName()))intent.setComponent(null);
            intent.setPackage(row.owner);
            if(intent.getAction()==null)intent.setAction(Intent.ACTION_VIEW);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.setClipData(null);
            activity.startActivity(intent);
        }catch(java.net.URISyntaxException|RuntimeException e){
            Toast.makeText(activity,"تعذر فتح بطاقة المتابعة في التطبيق الذي أرسلها",Toast.LENGTH_LONG).show();
        }
    }
    private static String emptyNext() {
        return "لا توجد بطاقات متابعة منشورة حاليًا. Watch Next يعرض الأعمال، وليس قائمة التطبيقات المثبتة. " +
            "في Watch Hub على التلفزيون: الإعدادات ← عرض قائمتي في Watch Next، ثم أضف عملًا بحالة أشاهد حاليًا. " +
            "التطبيقات الأخرى تظهر عندما تنشر بطاقات يدعمها نظام التلفزيون؛ وجود Netflix أو كرنشي رول وحده لا يضمن ذلك.";
    }
    static void showNext(Activity activity) {
        if(activity.checkSelfPermission(READ_LISTINGS)!=PackageManager.PERMISSION_GRANTED){
            new android.app.AlertDialog.Builder(activity).setTitle("متابعة المشاهدة")
                .setMessage("يلزم السماح للانشر بقراءة قوائم التلفزيون لعرض بطاقات التطبيقات.")
                .setPositiveButton("السماح",(d,w)->activity.requestPermissions(new String[]{READ_LISTINGS},74))
                .setNegativeButton("إغلاق",null).show();return;
        }
        java.util.concurrent.ExecutorService worker=Executors.newSingleThreadExecutor();
        worker.execute(()->{
            NextResult result=readNext(activity);
            activity.runOnUiThread(()->{
                if(activity.isFinishing()||activity.isDestroyed())return;
                android.app.AlertDialog.Builder dialog=new android.app.AlertDialog.Builder(activity)
                    .setTitle("متابعة المشاهدة — Watch Next").setNegativeButton("إغلاق",null);
                if(result.error!=null)dialog.setMessage(result.error);
                else if(result.rows.isEmpty())dialog.setMessage(emptyNext());
                else dialog.setItems(result.rows.stream().map(row->row.label).toArray(String[]::new),
                    (d,index)->openNext(activity,result.rows.get(index)));
                dialog.show();
            });
        });
        worker.shutdown();
    }
    void refreshNext() { loadNext(); }
    private void loadNext() {
        if (!active) return;
        int token=++generation;
        if (activity.checkSelfPermission(READ_LISTINGS)!=PackageManager.PERMISSION_GRANTED) {
            next.removeAllViews();nextScroll.setVisibility(VISIBLE);
            next.addView(chip("السماح بعرض متابعة المشاهدة",()->activity.requestPermissions(new String[]{READ_LISTINGS},74)));
            return;
        }
        reader.execute(()-> {
            NextResult result=readNext(activity);
            handler.post(()-> {
                if(!active||token!=generation)return;
                next.removeAllViews();
                nextScroll.setVisibility(result.rows.isEmpty()?GONE:VISIBLE);
                for(NextRow row:result.rows) {
                    TextView card=chip(row.label,()->openNext(activity,row));
                    card.setSingleLine(true);card.setEllipsize(TextUtils.TruncateAt.END);
                    card.setContentDescription(row.label);
                    LinearLayout.LayoutParams position=new LinearLayout.LayoutParams(dp(230),-1);
                    position.setMarginEnd(dp(6));next.addView(card,position);
                }
            });
        });
    }
}
