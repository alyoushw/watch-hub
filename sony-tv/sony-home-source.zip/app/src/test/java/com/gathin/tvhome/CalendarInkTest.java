package com.gathin.tvhome;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Arrays;

public class CalendarInkTest {
    private int[] paper(int w,int h){int[] p=new int[w*h];Arrays.fill(p,0xFFFFFFFF);return p;}
    @Test public void paperIsTransparent(){for(int p:CalendarInk.transparentWhite(paper(80,32),80,32))assertEquals(0,p>>>24);}
    @Test public void originalColoredAndBlackGlyphsRemain(){
        int[] p=paper(80,32);p[10*80+10]=0xFF1255B5;p[10*80+20]=0xFFCC2040;p[10*80+30]=0xFF101010;
        int[] q=CalendarInk.transparentWhite(p,80,32);
        for(int x:new int[]{10,20,30}){assertTrue((q[10*80+x]>>>24)>100);assertEquals(0xFFFFFF,q[10*80+x]&0xFFFFFF);}
    }
    @Test public void tableRulesDisappearButTallDigitRemains(){
        int[] p=paper(100,40);
        for(int x=0;x<100;x++)p[x]=0xFF666666;
        for(int y=0;y<40;y++)p[y*100]=0xFF666666;
        // A thin printed one is a legitimate glyph, not a table boundary.
        for(int y=8;y<30;y++)for(int x=44;x<46;x++)p[y*100+x]=0xFF111111;
        int[] q=CalendarInk.transparentWhite(p,100,40);
        for(int x=0;x<100;x++)assertEquals(0,q[x]>>>24);
        assertTrue((q[15*100+45]>>>24)>200);
    }
    @Test public void colonDotsArePreserved(){
        int[] p=paper(100,40);p[12*100+50]=0xFF000000;p[23*100+50]=0xFF000000;
        int[] q=CalendarInk.transparentWhite(p,100,40);assertEquals(255,q[12*100+50]>>>24);assertEquals(255,q[23*100+50]>>>24);
    }
}
