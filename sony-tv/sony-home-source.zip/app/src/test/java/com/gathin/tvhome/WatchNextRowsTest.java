package com.gathin.tvhome;

import org.junit.Test;
import static org.junit.Assert.*;

public class WatchNextRowsTest {
    @Test public void acceptsDifferentProvidersInsteadOfFilteringToWatchHub() {
        assertTrue(WatchNextRows.usable("com.alyoushw.watchhub","watchhub://detail/tv/123"));
        assertTrue(WatchNextRows.usable("com.netflix.ninja","nflx://watch/123"));
        assertTrue(WatchNextRows.usable("com.crunchyroll.crunchyroid","https://www.crunchyroll.com/watch/example"));
        assertTrue(WatchNextRows.usable("tv.other.receiver","intent://watch#Intent;scheme=video;end"));
    }
    @Test public void rejectsMissingOwnerOrPlaybackUri() {
        assertFalse(WatchNextRows.usable(null,"https://example.org"));
        assertFalse(WatchNextRows.usable("","https://example.org"));
        assertFalse(WatchNextRows.usable("com.example/video","https://example.org"));
        assertFalse(WatchNextRows.usable("com.example",null));
        assertFalse(WatchNextRows.usable("com.example","  "));
    }
    @Test public void labelsKeepSourceAndEpisodeIdentity() {
        assertEquals("Netflix · Example · 2/5",WatchNextRows.label("Netflix","Example","2","5"));
        assertEquals("Other · Film",WatchNextRows.label("Other","Film",null,null));
    }
    @Test public void missingSeasonDoesNotProduceNullText() {
        assertEquals("App · Show · 5",WatchNextRows.label("App","Show",null,"5"));
        assertEquals("App · متابعة المشاهدة",WatchNextRows.label("App",null,null,null));
    }
}
