package com.gathin.tvhome;
import org.junit.Test;
import static org.junit.Assert.*;

public class MirrorNamesTest {
    @Test public void ordinaryInputsAreNotMirroring(){assertFalse(MirrorNames.isMirroring("HDMI 1"));assertFalse(MirrorNames.isMirroring("Live TV"));assertFalse(MirrorNames.isMirroring(null));}
    @Test public void receiverLabelsInBothLanguagesAreDetected(){assertTrue(MirrorNames.isMirroring("Screen Mirroring"));assertTrue(MirrorNames.isMirroring("MIRACAST"));assertTrue(MirrorNames.isMirroring("تكرار الشاشة"));assertTrue(MirrorNames.isMirroring("انعكاس الشاشة"));}
    @Test public void factoryActivitiesCannotEnterReceiverPicker(){assertTrue(MirrorNames.isServiceOrFactory("com.mediatek.factorymenu/.Main"));assertTrue(MirrorNames.isServiceOrFactory("com.sony.dtv.servicemode/.Main"));assertFalse(MirrorNames.isServiceOrFactory("com.sony.dtv.networkapp.wifidirect/.ui.screens.ScreenMirroringHomeActivity"));}
}
